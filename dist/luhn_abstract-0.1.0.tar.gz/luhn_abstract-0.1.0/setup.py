from setuptools import setup,find_packages

setup(
	name='luhn_abstract',
	version='0.1.0',
	author='',
	author_email='',
	description='',
	packages=find_packages(),
	classifiers=[
		'Programming Language :: Python :: 3',
		'License :: OSI Approved :: GPLv3',
		'Operating System :: OS Independent',
	],
	python_requires='>=3.6',
)